import os
from .app import runServer
runServer()
os.environ['FLASK_APP'] = ifscApi.app
